package com.example.pro1;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

public class Tablerow extends LinearLayout {
    public Tablerow(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }
    public Tablerow(Context context){
        super(context);
        init(context);
    }

    private void init(Context context){
        LayoutInflater inflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.tablerow,this,true);
    }
}
