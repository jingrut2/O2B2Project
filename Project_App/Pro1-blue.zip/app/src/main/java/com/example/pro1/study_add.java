package com.example.pro1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class study_add extends AppCompatActivity {

//    private static study_add mstudy_add=null;
//    public study_add(){
//
//    }
//    public static study_add getInstance(){
//        if(mstudy_add==null)
//            mstudy_add=new study_add();
//        return mstudy_add;
//    }
    String dbName = "schedule.db";
    static String tableName="schdule";

    int realnum1=0;
    int realnum2=0;
    TextView subnum=null;
    TextView time=null;
    Button plus1=null;
    Button plus2,minus1,minus2,ok;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_add);
        Log.d("test","study_add 들어옴");

        subnum=(TextView) findViewById(R.id.subnum);
        time=(TextView)findViewById(R.id.time);
        plus1=(Button)findViewById(R.id.plus1);
        plus2=(Button)findViewById(R.id.plus2);
        minus1=(Button)findViewById(R.id.minus1);
        minus2=(Button)findViewById(R.id.minus2);
        ok=(Button)findViewById(R.id.ok);


        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realnum1++;
                subnum.setText(""+realnum1);
            }
        });

        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realnum1--;
                subnum.setText(""+realnum1);
                if(realnum1<0){
                    subnum.setText("음수불가");
                }
            }
        });
        plus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realnum2++;
                time.setText(""+realnum2);
            }
        });

        minus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realnum2--;
                time.setText(""+realnum2);
                if(realnum2<0){
                    subnum.setText("음수불가");
                }
            }
        });


 /*
        helper = new DatabaseHelper2(
                this,  // 현재 화면의 제어권자
                dbName,// db 이름
                null,  // 커서팩토리-null : 표준커서가 사용됨
                dbVersion);       // 버전

        try {

            db = helper.getWritableDatabase(); // 읽고 쓸수 있는 DB
            //db = helper.getReadableDatabase(); // 읽기 전용 DB select문
            Log.d("test","getWritableDatabase");
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e(tag, "데이터베이스를 얻어올 수 없음");
            finish(); // 액티비티 종료
        }
       */
        final ScheduleDBManager mDB = new ScheduleDBManager();
        boolean isDBConnect =  mDB.setScheduleDB(this, tableName, dbName);
        if(!isDBConnect)
                finish();

        Date currentTime = Calendar.getInstance().getTime();
        final String date_text = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(currentTime);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_subnum=subnum.getText().toString();
                String s_time=time.getText().toString();


                if ("".equals(s_subnum) || "".equals(s_time) ) {
                    Toast.makeText(getApplicationContext(),"insert 실패 - 항목을 입력하세요",Toast.LENGTH_SHORT).show();
                    return;// 그냥 빠져나감
                }

                mDB.DBinsert(date_text,s_subnum,s_time,tableName);

                Intent intent = new Intent();

                intent.putExtra("result", "입력됨");
                intent.putExtra("result1", date_text);
                intent.putExtra("result2", s_subnum);
                intent.putExtra("result3", s_time);
                setResult(RESULT_OK, intent);

                finish();



            }
        });


    }

//    void insert(String date_text,String s_subnum,String s_time){
//        ContentValues values = new ContentValues();
//        // 키,값의 쌍으로 데이터 입력
//        values.put("date_text", date_text);
//        values.put("s_subnum", s_subnum);
//        values.put("s_time", s_time);
//
//        long result = db.insert(tableName, null, values);
//        Log.d(tag, "입력 성공했음");
//
//        schedule.textView.setText(result + "번째 row insert 성공했음");
//
//        Log.d("test", ""+date_text);
//        Log.d("test", ""+s_subnum);
//        Log.d("test", ""+s_time);
//
//        Log.d("test",""+result);
//
//        Intent intent = new Intent();
//
//        intent.putExtra("result", "입력됨");
//        intent.putExtra("result1", date_text);
//        intent.putExtra("result2", s_subnum);
//        intent.putExtra("result3", s_time);
//        setResult(RESULT_OK, intent);
//
//        finish();
//
//    }


}
