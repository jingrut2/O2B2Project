package com.example.pro1;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class schedule extends AppCompatActivity {

    String dbName = "st_file.db";
    String dbName2 = "schedule.db";
    String tag = "SQLite";
    String tableName="mytable";
    String tableName2="schdule";
    EditText date;
    static TextView tv;//db에 저장된거 보여주는곳
    Button binsert,bselect,bdelete;

    Button alert1,studyadd;//팝업창을위한거


    static TextView DBdate,DBsub,DBtime,textView;


    final int REQUEST_TEST = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        textView=(TextView)findViewById(R.id.textview);
        DBdate=(TextView)findViewById(R.id.DBdate);


        alert1 = (Button) findViewById(R.id.addfrdbtn);
        alert1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Context mContext = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);

                View layout = inflater.inflate(R.layout.add_frd, (ViewGroup) findViewById(R.id.popup));
                AlertDialog.Builder aDialog = new AlertDialog.Builder(schedule.this);
                aDialog.setTitle("친구추가 창");
                aDialog.setView(layout);

                aDialog.setNegativeButton("닫기", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                aDialog.setNegativeButton("추가하기", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(),"click",Toast.LENGTH_SHORT).show();
                    }
                });

                AlertDialog ad = aDialog.create();
                ad.show();


            }
        });


        studyadd=(Button)findViewById(R.id.studyadd);
        studyadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("test","추가버튼클릭");
                Intent intent = new Intent(getApplicationContext(), study_add.class);
                startActivityForResult(intent, REQUEST_TEST);

            }
        });

        date = (EditText) findViewById(R.id.date);
        final EditText c_num=(EditText)findViewById(R.id.c_num);

        TabHost tabHost1 = (TabHost) findViewById(R.id.tabHost1);
        tabHost1.setup();

        // 첫 번째 Tab. (탭 표시 텍스트:"TAB 1"), (페이지 뷰:"content1")
        TabHost.TabSpec ts1 = tabHost1.newTabSpec("Tab Spec 1");
        ts1.setContent(R.id.content1);
        ts1.setIndicator("저장된 일정");
        tabHost1.addTab(ts1);

        // 두 번째 Tab. (탭 표시 텍스트:"TAB 2"), (페이지 뷰:"content2")
        TabHost.TabSpec ts2 = tabHost1.newTabSpec("Tab Spec 2");
        ts2.setContent(R.id.content2);
        ts2.setIndicator("한눈에 보기");
        tabHost1.addTab(ts2);

        // 세 번째 Tab. (탭 표시 텍스트:"TAB 3"), (페이지 뷰:"content3")
        TabHost.TabSpec ts3 = tabHost1.newTabSpec("Tab Spec 3");
        ts3.setContent(R.id.content3);
        ts3.setIndicator("랭킹");
        tabHost1.addTab(ts3);

        tv = (TextView) findViewById(R.id.textView4);

        binsert = (Button) findViewById(R.id.insert);
        bselect = (Button) findViewById(R.id.select);
        bdelete = (Button) findViewById(R.id.delete);

/*
        helper = new DatabaseHelper(
                this,  // 현재 화면의 제어권자
                dbName,// db 이름
                null,  // 커서팩토리-null : 표준커서가 사용됨
                dbVersion);       // 버전

        try {

            db = helper.getWritableDatabase(); // 읽고 쓸수 있는 DB
            //db = helper.getReadableDatabase(); // 읽기 전용 DB select문
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e(tag, "데이터베이스를 얻어올 수 없음");
            finish(); // 액티비티 종료
        }
*/

        final ScheduleDBManager mDB = new ScheduleDBManager();
        boolean isDBConnect =  mDB.setScheduleDB(this, tableName, dbName);
        if(!isDBConnect)
            finish();
        mDB.select(tableName);//앱 키자마자 일정조회


        final ScheduleDBManager mDB2 = new ScheduleDBManager();
        boolean isDBConnect2 =  mDB2.setScheduleDB(this, tableName2, dbName2);
        if(!isDBConnect2)
            finish();

        mDB2.addview(tableName2);

        Button but=(Button)findViewById(R.id.b1);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DBdate.setText("");
                mDB2.addview(tableName2);

            }
        });

        binsert.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                String s_date = date.getText().toString();

                if ("".equals(s_date)) {
                    tv.setText("insert 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }


                mDB.insert(s_date,tableName);

                mDB.select(tableName);
                int num=tv.getLineCount()-1;
                String _num=Integer.toString(num);
                c_num.setText(_num);

                date.setText("");
            }

        });

        bselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int num=0;
                num=tv.getLineCount()-1;
                String _num=Integer.toString(num);
                c_num.setText(_num);

                tv.setText("");//기존에 textView에 있는 값을 지우고 보여주기
                mDB.select(tableName);
                date.setText("");//입력창에있는거 지우기
            }
        });


        bdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_date=date.getText().toString();

                if ("".equals(s_date)) {
                    tv.setText("delete 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }

                mDB.delete(s_date,tableName);

                int num=tv.getLineCount()-1;
                String _num=Integer.toString(num);
                c_num.setText(_num);

                date.setText("");
            }
        });




    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_TEST) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "Result: " + data.getStringExtra("result"), Toast.LENGTH_SHORT).show();

                DBdate.append(data.getStringExtra("result1"));
                DBdate.append(", "+data.getStringExtra("result2"));
                DBdate.append(",개 "+data.getStringExtra("result3")+"시간\n");

            } else {   // RESULT_CANCEL
                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
            }
//        } else if (requestCode == REQUEST_ANOTHER) {
//            ...
        }
    }


}
