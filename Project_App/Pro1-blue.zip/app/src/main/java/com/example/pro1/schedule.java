package com.example.pro1;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class schedule extends AppCompatActivity {

    private DatabaseHelper helper;
    String dbName = "st_file.db";
    int dbVersion = 3; // 데이터베이스 버전
    private SQLiteDatabase db;
    String tag = "SQLite";
    String tableName="mytable";

    EditText date;
    TextView tv;//db에 저장된거 보여주는곳
    Button bselect,bdelete;

    Button alert;//팝업창을위한거
    String s_date;//date를 스트링으로 받아오는거


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        alert=(Button)findViewById(R.id.addfrdbtn);
        alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Context mContext = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);

                View layout = inflater.inflate(R.layout.add_frd, (ViewGroup) findViewById(R.id.popup));
                AlertDialog.Builder aDialog = new AlertDialog.Builder(schedule.this);
                aDialog.setTitle("친구추가 창");
                aDialog.setView(layout);

                aDialog.setNegativeButton("닫기", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                AlertDialog ad = aDialog.create();
                ad.show();


            }
        });
        Button adddbbtn=(Button)findViewById(R.id.adddbbtn);
        date=(EditText)findViewById(R.id.date);


        TabHost tabHost1 = (TabHost) findViewById(R.id.tabHost1) ;
        tabHost1.setup() ;

        // 첫 번째 Tab. (탭 표시 텍스트:"TAB 1"), (페이지 뷰:"content1")
        TabHost.TabSpec ts1 = tabHost1.newTabSpec("Tab Spec 1") ;
        ts1.setContent(R.id.content1) ;
        ts1.setIndicator("저장된 일정") ;
        tabHost1.addTab(ts1)  ;

        // 두 번째 Tab. (탭 표시 텍스트:"TAB 2"), (페이지 뷰:"content2")
        TabHost.TabSpec ts2 = tabHost1.newTabSpec("Tab Spec 2") ;
        ts2.setContent(R.id.content2) ;
        ts2.setIndicator("한눈에 보기") ;
        tabHost1.addTab(ts2) ;

        // 세 번째 Tab. (탭 표시 텍스트:"TAB 3"), (페이지 뷰:"content3")
        TabHost.TabSpec ts3 = tabHost1.newTabSpec("Tab Spec 3") ;
        ts3.setContent(R.id.content3) ;
        ts3.setIndicator("랭킹") ;
        tabHost1.addTab(ts3);

        tv = (TextView)findViewById(R.id.textView4);
        bselect=(Button)findViewById(R.id.select);
        bdelete=(Button)findViewById(R.id.delete);


        helper = new DatabaseHelper(
                this,  // 현재 화면의 제어권자
                dbName,// db 이름
                null,  // 커서팩토리-null : 표준커서가 사용됨
                dbVersion);       // 버전

        try {
//         // 데이터베이스 객체를 얻어오는 다른 간단한 방법
//         db = openOrCreateDatabase(dbName,  // 데이터베이스파일 이름
//                          Context.MODE_PRIVATE, // 파일 모드
//                          null);    // 커서 팩토리
//
//         String sql = "create table mytable(id integer primary key autoincrement, name text);";
//        db.execSQL(sql);

            db = helper.getWritableDatabase(); // 읽고 쓸수 있는 DB
            //db = helper.getReadableDatabase(); // 읽기 전용 DB select문
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e(tag, "데이터베이스를 얻어올 수 없음");
            finish(); // 액티비티 종료
        }




        adddbbtn.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v) {
                String s_date=date.getText().toString();

                if ("".equals(s_date)){
                    tv.setText("insert 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }


                insert (s_date);

                select();

                date.setText("");
            }

        });

        bselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText("");//기존에 textView에 있는 값을 지우고 보여주기
                select();
                date.setText("");
            }
        });



        bdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s_date = date.getText().toString();

                if ("".equals(s_date)){
                    tv.setText("delete 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }

                delete(s_date);

                date.setText("");
            }
        });


    }

    void insert(String date){
        ContentValues values = new ContentValues();
        // 키,값의 쌍으로 데이터 입력
        values.put("date", date);

        long result = db.insert(tableName, null, values);
        Log.d(tag, result + "번째 row insert 성공했음");
        tv.setText(result + "번째 row insert 성공했음");
       // select(); // insert 후에 select 하도록

    }
    void select() {
        Cursor c = db.query(tableName, null, null, null, null, null, null);
        while(c.moveToNext()) {
            int _id = c.getInt(0);
            String date = c.getString(1);


            Log.d(tag,"id:"+_id+" date:"+date);
            tv.append("\n"+"id:"+_id+" date:"+date);

            // 키보드 내리기
            InputMethodManager imm =
                    (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow
                    (getCurrentFocus().getWindowToken(), 0);
        }

    }
    void delete(String s_date) {
        int result = db.delete(tableName, "date=?", new String[] {s_date});
        Log.d(tag, result + "개 row delete 성공");
        tv.setText(result + "개 row delete 성공");
        select(); // delete 후에 select 하도록
    }






}
