package com.example.pro1;

import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class DBManager {
    static DBManager dbManager;
    private Handler mHandler;
    static Socket socket=null;
    static String ID ="";
    static String PW = "";
    private DBManager(){

    }

    public static DBManager getInstance(){

        if(dbManager == null)
            dbManager = new DBManager();
        return dbManager;
    }

    void connect() {
        {
            mRead m = new mRead();
            m.start();
        }

    }

    void setOutput(String ID, String PW){
        DBManager.ID = ID;
        DBManager.PW = PW;
        mWrite m = new mWrite();
        m.start();
    }
}


class mWrite extends Thread{

    @Override
    public void run() {
        super.run();

        try {
            Log.w("Bt", "버튼이 눌려짐");

            OutputStream out1 = DBManager.socket.getOutputStream();
            PrintWriter pw1 = new PrintWriter(out1, true);
            pw1.println(DBManager.ID);

            InputStream in1 = DBManager.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echo = br1.readLine();
            Log.w("서버에서 받아온 값", ""+echo);

            if(echo.equals("1")){
                OutputStream out2 = DBManager.socket.getOutputStream();
                PrintWriter pw2 = new PrintWriter(out2, true);
                pw2.println(DBManager.PW);
            }

        }catch (Exception e)
        {
            e.printStackTrace();
            Log.w("버퍼", "버퍼생성 잘못됨");
        }
        Log.w("버퍼","버퍼생성 잘됨");
    }
}

class mRead extends Thread {
    @Override
    public void run() {
        super.run();

        String ip = "192.168.43.81";            // IP 번호
        int port = 3154;
        try {
            DBManager.socket = new Socket(ip, port);
            Log.w("서버 접속됨", "서버 접속됨");
        } catch (IOException e1) {
            Log.w("서버접속못함", "서버접속못함");
            e1.printStackTrace();
        }
        Log.w("edit 넘어가야 할 값 : ","안드로이드에서 서버로 연결요청");

        try {

            OutputStream out = DBManager.socket.getOutputStream();
            PrintWriter pw = new PrintWriter(out, true);
            pw.println("Client Message.");

            InputStream in = DBManager.socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String echo = br.readLine();
            Log.w("서버에서 받아온 값", ""+echo);

        } catch (IOException e) {
            e.printStackTrace();
            Log.w("버퍼", "버퍼생성 잘못됨");
        }
        Log.w("버퍼","버퍼생성 잘됨");
    }
}


