package com.example.pro1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    final int ID=1234;
    final int PW=5678;
    EditText IPID,IPPW;
    String sId,sPw;

    private String html = "";
    private Handler mHandler;

    private Socket socket;

    private DataOutputStream dos;
    private DataInputStream dis;

    private String ip = "192.168.43.81";            // IP 번호
    private int port = 3154;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBManager m = DBManager.getInstance();
        m.connect();




        TextView joinbtn=findViewById(R.id.joinbtn);
        Button loginbtn=findViewById(R.id.loginbtn);

        IPID=(EditText)findViewById(R.id.ipid);
        IPPW=(EditText)findViewById(R.id.ippw);


//        sPw=IPPW.getText().toString();


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(IPID.getText().toString().equals("") || IPPW.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "값이 없습니다.", Toast.LENGTH_LONG).show();
                }else if(IPID.getText().toString().equals("1234") && IPPW.getText().toString().equals("5678")){
                    Intent intent=new Intent(getApplicationContext(),schedule.class);
                    startActivity(intent);
                    finish();
                }else if(IPID.getText().toString().equals("1234") ^ IPPW.getText().toString().equals("5678")){
                    Toast.makeText(MainActivity.this, "id나 비밀번호가 틀렸습니다.", Toast.LENGTH_LONG).show();
                }
                sId=IPID.getText().toString();
                Log.d("settext","------------");
                DBManager m = DBManager.getInstance();
                m.setOutput(sId);
            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),join.class);
                startActivity(intent);
                finish();
            }
        });
    }






    void connect(){
        mHandler = new Handler();
        Log.w("kjs_connect","연결 하는중");
        // 받아오는거
        Thread checkUpdate = new Thread() {
            public void run() {


                // 서버 접속
                try {
                    Log.w("kjs_connect", "서버 시도....");
                    socket = new Socket(ip, port);
                    Log.w("kjs_connect", "서버 접속됨");
                } catch (IOException e1) {
                    Log.w("kjs_connect", "서버접속못함");
                    e1.printStackTrace();
                }

                Log.w("kjs_connect","안드로이드에서 서버로 연결요청");

                try {
                    dos = new DataOutputStream(socket.getOutputStream());   // output에 보낼꺼 넣음
                    dis = new DataInputStream(socket.getInputStream());     // input에 받을꺼 넣어짐
                    dos.writeUTF("안드로이드에서 서버로 연결요청");

                } catch (IOException e) {
                    e.printStackTrace();
                    Log.w("kjs_connect", "버퍼생성 잘못됨");
                }
                Log.w("kjs_connect","버퍼생성 잘됨");



                // 서버에서 계속 받아옴 - 한번은 문자, 한번은 숫자를 읽음. 순서 맞춰줘야 함.
                try {
                    String line = "";
                    int line2;
                    while(true) {
                        line = (String)dis.readUTF();
                        line2 = (int)dis.read();
                        Log.w("kjs_connect",""+line);
                        Log.w("kjs_connect",""+line2);
                    }
                }catch (Exception e){

                }
            }
        };
        // 소켓 접속 시도, 버퍼생성
        checkUpdate.start();
    }


}





