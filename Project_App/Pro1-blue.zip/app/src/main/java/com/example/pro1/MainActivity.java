package com.example.pro1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    final int ID=1234;
    final int PW=5678;
    EditText IPID,IPPW;
//    String sId,sPw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TextView joinbtn=findViewById(R.id.joinbtn);
        Button loginbtn=findViewById(R.id.loginbtn);

        IPID=(EditText)findViewById(R.id.ipid);
        IPPW=(EditText)findViewById(R.id.ippw);

//        sId=IPID.getText().toString();
//        sPw=IPPW.getText().toString();


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(IPID.getText().toString().equals("") || IPPW.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "값이 없습니다.", Toast.LENGTH_LONG).show();
                }else if(IPID.getText().toString().equals("1234") && IPPW.getText().toString().equals("5678")){
                    Intent intent=new Intent(getApplicationContext(),schedule.class);
                    startActivity(intent);
                    finish();
                }else if(IPID.getText().toString().equals("1234") ^ IPPW.getText().toString().equals("5678")){
                    Toast.makeText(MainActivity.this, "id나 비밀번호가 틀렸습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),join.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
