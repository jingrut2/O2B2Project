package com.example.pro1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    final int ID = 1234;
    final int PW = 5678;

    EditText IPID, IPPW;
    String sId, sPw;
    int count = 0;

    static String TrueID = "";
    static String TruePW = "";

    private String html = "";
    private Handler mHandler;

    private Socket socket;

    private DataOutputStream dos;
    private DataInputStream dis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBManager m = DBManager.getInstance();
        m.connect();
        Log.d("로그 : settext", "------------연결됨");


        TextView joinbtn = findViewById(R.id.joinbtn);
        Button loginbtn = findViewById(R.id.loginbtn);

        IPID = (EditText) findViewById(R.id.ipid);
        IPPW = (EditText) findViewById(R.id.ippw);


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sId = IPID.getText().toString();
                sPw = IPPW.getText().toString();
                Log.d("settext", "------------");
                DBManager m = DBManager.getInstance();
                m.setOutput(sId, sPw);




                while (true) {
                    try {
                        Thread.sleep(250);
                    } catch (Exception e) {

                    }
                    if (MainActivity.TrueID.equals("1")) {
                        Log.w("로그 : ID 값을 True 받음", "ID 값을 True 받음" );
                        break;
                    }
                    else if(count == 10) {
                        Log.w("로그 :ID count", "count : " + count);
                        break;
                    }

                    else
                        count++;
                }





                if (MainActivity.TrueID.equals("") || MainActivity.TruePW.equals("")) {
                    Toast.makeText(MainActivity.this, "값이 없습니다.", Toast.LENGTH_LONG).show();
                } else if (MainActivity.TrueID.equals("1") && MainActivity.TruePW.equals("1")) {
                    Intent intent = new Intent(getApplicationContext(), schedule.class);
                    startActivity(intent);
                    finish();
                } else if (!MainActivity.TrueID.equals("1") ^ !MainActivity.TruePW.equals("1")) {
                    Toast.makeText(MainActivity.this, "id나 비밀번호가 틀렸습니다.", Toast.LENGTH_LONG).show();
                }


            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), join.class);
                startActivity(intent);
                finish();
            }
        });
    }

//    void connect(){
//        mHandler = new Handler();
//        Log.w("kjs_connect","연결 하는중");
//        // 받아오는거
//        Thread checkUpdate = new Thread() {
//            public void run() {
//
//
//                // 서버 접속
//                try {
//                    Log.w("kjs_connect", "서버 시도....");
//                    socket = new Socket(ip, port);
//                    Log.w("kjs_connect", "서버 접속됨");
//                } catch (IOException e1) {
//                    Log.w("kjs_connect", "서버접속못함");
//                    e1.printStackTrace();
//                }
//
//                Log.w("kjs_connect","안드로이드에서 서버로 연결요청");
//
//                try {
//                    dos = new DataOutputStream(socket.getOutputStream());   // output에 보낼꺼 넣음
//                    dis = new DataInputStream(socket.getInputStream());     // input에 받을꺼 넣어짐
//                    dos.writeUTF("안드로이드에서 서버로 연결요청");
//
//                } catch (IOException e) {
//                    e.printStackTrace();
//                    Log.w("kjs_connect", "버퍼생성 잘못됨");
//                }
//                Log.w("kjs_connect","버퍼생성 잘됨");
//
//
//
//                // 서버에서 계속 받아옴 - 한번은 문자, 한번은 숫자를 읽음. 순서 맞춰줘야 함.
//                try {
//                    String line = "";
//                    int line2;
//                    while(true) {
//                        line = (String)dis.readUTF();
//                        line2 = (int)dis.read();
//                        Log.w("kjs_connect",""+line);
//                        Log.w("kjs_connect",""+line2);
//                    }
//                }catch (Exception e){
//
//                }
//            }
//        };
//        // 소켓 접속 시도, 버퍼생성
//        checkUpdate.start();
//    }


}





