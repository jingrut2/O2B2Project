package com.example.pro1;

import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import android.util.Log;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


public class DBManager {
    static DBManager dbManager;
    private Handler handler;
    static Socket socket = null;
    static String ID = "";
    static String PW = "";
    static String echoID = "";
    static String echoPW = "";

    private DBManager() {

    }

    public static DBManager getInstance() {

        if (dbManager == null)
            dbManager = new DBManager();
        return dbManager;
    }

    void connect() {
        {
            mRead m = new mRead();
            m.start();
        }

    }

    void setOutput(String ID, String PW) {
        DBManager.ID = ID;
        DBManager.PW = PW;
        mWrite m = new mWrite();
        m.start();
    }
}

class mWrite extends Thread {

    @Override
    public void run() {
        super.run();

        try {
            Log.w("로그 : Bt", "버튼이 눌려짐");

            Log.w("로그 서버에서 아이디 주고받기", "OK");
            OutputStream out1 = DBManager.socket.getOutputStream();
            PrintWriter pw1 = new PrintWriter(out1, true);
            pw1.println(DBManager.ID);  // 입력된 ID 서버에 보냄

            InputStream in1 = DBManager.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine(); // 대기하다 서버에서 판별값을 받음
            MainActivity.TrueID = echoID;  // 판별값을 MAIN 에서사용하는 매개변수에 저장
            Log.w("로그 서버에서 받은 ID 판별 값 : ", "" + echoID);


            if (echoID.equals("1")) { // 입력한 ID가 맞다면 진입

                Log.w("로그 서버에서 패스워드 주고받기", "OK");
                OutputStream out2 = DBManager.socket.getOutputStream();
                PrintWriter pw2 = new PrintWriter(out2, true);
                pw2.println(DBManager.PW); // 입력된 PW 서버에 보냄

                InputStream in2 = DBManager.socket.getInputStream();
                BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
                String echoPW = br2.readLine(); // 대기하다 서버에서 판별값을 받음
                MainActivity.TruePW = echoPW;  // 판별값을 MAIN 에서 사용하는 매개변수에 저장
                Log.w("로그 서버에서 받은 PW 판별 값 : ", "" + echoPW);
            }

            else if(echoID.equals("0")) {
                MainActivity.TruePW = "0";
            }
            else if(echoID.equals("")) {
                MainActivity.TruePW = "";
            }


        } catch (Exception e) {
            e.printStackTrace();
            Log.w("로그 버퍼", "버퍼생성 잘못됨");
        }
        Log.w("로그 버퍼", "버퍼생성 잘됨");
    }
}


class mRead extends Thread {
    @Override
    public void run() {
        super.run();

        String ip = "192.168.43.81";            // IP 번호
        int port = 3154;
        try {
            DBManager.socket = new Socket(ip, port);
            Log.w("로그 서버 접속됨", "서버 접속됨");
        } catch (IOException e1) {
            Log.w("로그 서버접속못함", "서버접속못함");
            e1.printStackTrace();
        }
        Log.w("로그 edit 넘어가야 할 값 : ", "안드로이드에서 서버로 연결요청");

        try {

            OutputStream out = DBManager.socket.getOutputStream();
            PrintWriter pw = new PrintWriter(out, true);
            pw.println("Client Message.");

            InputStream in = DBManager.socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String echo_connect = br.readLine();
            Log.w("로그 서버에서 받아온 값", "" + echo_connect);

        } catch (IOException e) {
            e.printStackTrace();
            Log.w("로그 버퍼", "버퍼생성 잘못됨");
        }
        Log.w("로그 버퍼", "버퍼생성 잘됨");
    }
}

