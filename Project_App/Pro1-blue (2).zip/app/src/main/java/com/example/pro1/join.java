package com.example.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class join extends AppCompatActivity {

    static String TruePN = "";
    static String Truepw1 = "";
    static String Truepw2 = "";
    static String TrueSN = "";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join);
        setTitle("회원가입");

        final EditText phoneEt = findViewById(R.id.phoneEt);
        final EditText pw1 = findViewById(R.id.pw1);
        final EditText pw2 = findViewById(R.id.pw2);
        final EditText Serialnum = findViewById(R.id.serialnum);
        Button joinb = findViewById(R.id.joinb);


        joinb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (phoneEt.getText().toString().equals("") || pw1.getText().toString().equals("") || pw2.getText().toString().equals("") || Serialnum.getText().toString().equals("")) {
                    Toast.makeText(join.this, "입력칸을 모두 채워주세요.", Toast.LENGTH_LONG).show();
                } else if (!pw1.getText().toString().equals(pw2.getText().toString())) {
                    Toast.makeText(join.this, "비밀번호값이 다릅니다. 다시 입력해주세요.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(join.this, "회원가입되었습니다. 로그인해주세요", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

    }
}
